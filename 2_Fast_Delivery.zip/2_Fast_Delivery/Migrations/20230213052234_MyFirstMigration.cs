﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 

namespace FastDeliveryApi.Migrations
{
    /// <inheritdoc />
    public partial class MyFirstMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 2);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Id", "Address", "CreatedOnUtc", "Email", "ModifiedOnUtc", "Name", "PhoneNumberCustomer", "Status" },
                values: new object[,]
                {
                    { 1, "San Miguel", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "andrade@univo.edu.sv", null, "andrade lourdes", "1234-5678", true },
                    { 2, "Usulutan", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "jmolina@univo.edu.sv", null, "jacqueline molina", "1122-3344", true }
                });
        }
    }
}
